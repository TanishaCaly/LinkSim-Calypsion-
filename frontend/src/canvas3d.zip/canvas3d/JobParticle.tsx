import { useRef, useMemo, useEffect } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { makeLabelTexture } from './makeLabelTexture'
import type { Machine3D, Connection3D } from './layout'

interface JobParticleProps {
  machines: Machine3D[]
  connections: Connection3D[]
}

// ---- Tunables (previously scattered magic numbers) ----
const MAX_ACTIVE_JOBS = 20
const SPAWN_INTERVAL_SEC = 3
const BOTTLENECK_UTILIZATION_THRESHOLD = 85
const BOTTLENECK_DURATION_MULT = 0.4
const NORMAL_DURATION_MULT = 0.25
const MAX_PROCESS_DURATION = 3
const PROCESS_PROGRESS_MULT = 2.5
const TRAVEL_SPEED = 0.8
const QUEUE_GRID_SPACING = 0.35
const QUEUE_Z_OFFSET = 1.5
const SPHERE_HOVER_Y = 0.8

type JobStatus = 'traveling' | 'processing' | 'queued' | 'exited' | 'pooled'

interface JobState {
  id: number
  stepIndex: number
  progress: number
  sphereGroup: THREE.Group
  boxGroup: THREE.Group
  badge: THREE.Sprite
  status: JobStatus
  machineId: string
  lastQueueNum: number | null
}

let jobIdCounter = 0

function makeSphereGroup(): THREE.Group {
  const geo = new THREE.SphereGeometry(0.12, 10, 10)
  const mat = new THREE.MeshBasicMaterial({ color: '#60a5fa' })
  const mesh = new THREE.Mesh(geo, mat)
  const glowGeo = new THREE.SphereGeometry(0.22, 8, 8)
  const glowMat = new THREE.MeshBasicMaterial({ color: '#3b82f6', transparent: true, opacity: 0.5 })
  const glowMesh = new THREE.Mesh(glowGeo, glowMat)
  const group = new THREE.Group()
  group.add(mesh)
  group.add(glowMesh)
  group.add(new THREE.PointLight('#60a5fa', 1.5, 2))
  return group
}

function makeBoxGroup(): THREE.Group {
  const group = new THREE.Group()
  const geo = new THREE.BoxGeometry(0.28, 0.28, 0.28)
  const mat = new THREE.MeshStandardMaterial({ color: '#f59e0b', roughness: 0.4, metalness: 0.1 })
  const mesh = new THREE.Mesh(geo, mat)
  mesh.castShadow = true
  group.add(mesh)
  const edgeGeo = new THREE.EdgesGeometry(geo)
  const edgeMat = new THREE.LineBasicMaterial({ color: '#d97706', transparent: true, opacity: 0.6 })
  group.add(new THREE.LineSegments(edgeGeo, edgeMat))
  return group
}

function makeBadge(text: string): THREE.Sprite {
  const tex = makeLabelTexture({ text, fontSize: 10, backgroundColor: 'rgba(0,0,0,0.7)', padding: 2 })
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false })
  const sprite = new THREE.Sprite(mat)
  sprite.scale.set(0.35, 0.2, 1)
  sprite.position.y = 0.22
  return sprite
}

// Recursively dispose geometries/materials/textures under an object3D.
function disposeObject3D(obj: THREE.Object3D) {
  obj.traverse((child) => {
    if (child instanceof THREE.Mesh || child instanceof THREE.LineSegments) {
      child.geometry?.dispose()
      const mats = Array.isArray(child.material) ? child.material : [child.material]
      for (const m of mats) m?.dispose()
    }
    if (child instanceof THREE.Sprite) {
      const mat = child.material as THREE.SpriteMaterial
      mat.map?.dispose()
      mat.dispose()
    }
  })
}

function posKey(v: THREE.Vector3): string {
  return `${v.x.toFixed(2)},${v.y.toFixed(2)},${v.z.toFixed(2)}`
}

export default function JobParticle({ machines, connections }: JobParticleProps) {
  // Persistent three.js group we manage imperatively. Mounted once via
  // <primitive>; job sub-groups are added/removed with group.add/remove
  // rather than through React reconciliation, so spawning/pooling jobs
  // inside useFrame doesn't depend on triggering a re-render.
  const containerRef = useRef<THREE.Group>(new THREE.Group())
  const jobsRef = useRef<JobState[]>([])
  const initialized = useRef(false)
  const spawnTimer = useRef(0)

  const pipeline = useMemo(() => {
    const unique = new Map<string, Machine3D[]>()
    for (const m of machines) {
      if (!unique.has(m.baseName)) unique.set(m.baseName, [])
      unique.get(m.baseName)!.push(m)
    }
    const order: Machine3D[][] = []
    const seen = new Set<string>()
    for (const m of machines) {
      if (!seen.has(m.baseName)) {
        seen.add(m.baseName)
        order.push(unique.get(m.baseName)!)
      }
    }
    return order
  }, [machines])

  const machineBusy = useMemo(() => new Map<string, boolean>(), [])

  const machineDuration = useMemo(() => {
    const map = new Map<string, number>()
    for (const group of pipeline) {
      const m = group[0]
      const baseDur = m.steps[0]?.duration ?? 10
      const isBottleneck = m.utilization > BOTTLENECK_UTILIZATION_THRESHOLD
      map.set(m.baseName, Math.min(isBottleneck ? baseDur * BOTTLENECK_DURATION_MULT : baseDur * NORMAL_DURATION_MULT, MAX_PROCESS_DURATION))
    }
    return map
  }, [pipeline])

  const machinePositions = useMemo(() => {
    const map = new Map<string, THREE.Vector3[]>()
    for (const group of pipeline) {
      map.set(group[0].baseName, group.map(m => new THREE.Vector3(m.position[0], SPHERE_HOVER_Y, m.position[2])))
    }
    return map
  }, [pipeline])

  // Curves keyed by a stable position-pair string, computed once instead of
  // scanned-and-distanceTo'd against every connection on every frame.
  const connectionCurves = useMemo(() => {
    const map = new Map<string, THREE.QuadraticBezierCurve3>()
    for (const conn of connections) {
      const from = new THREE.Vector3(...conn.from)
      const to = new THREE.Vector3(...conn.to)
      const dir = new THREE.Vector3().subVectors(to, from)
      const len = dir.length()
      const mid = new THREE.Vector3().addVectors(from, to).multiplyScalar(0.5)
      const perp = new THREE.Vector3(-dir.z, 0, dir.x).normalize()
      const curveHeight = Math.min(len * 0.12, 0.6)
      const control = mid.clone()
      control.y += curveHeight
      control.add(perp.multiplyScalar(curveHeight * 0.3))
      map.set(`${posKey(from)}|${posKey(to)}`, new THREE.QuadraticBezierCurve3(from, control, to))
    }
    return map
  }, [connections])

  const getMachinePos = (stepIndex: number, machineId: string): THREE.Vector3 => {
    const group = pipeline[stepIndex]
    if (!group) return new THREE.Vector3()
    const m = group.find(x => x.id === machineId)
    return new THREE.Vector3(m?.position[0] ?? group[0].position[0], SPHERE_HOVER_Y, m?.position[2] ?? group[0].position[2])
  }

  const updateBadge = (job: JobState, queueNum: number) => {
    if (job.lastQueueNum === queueNum) return // avoid re-rendering an unchanged canvas texture every frame
    job.lastQueueNum = queueNum
    const tex = makeLabelTexture({ text: String(queueNum), fontSize: 10, backgroundColor: 'rgba(0,0,0,0.7)', padding: 2 })
    const mat = job.badge.material as THREE.SpriteMaterial
    mat.map?.dispose()
    mat.map = tex
    mat.needsUpdate = true
  }

  const positionQueueStack = (stepIndex: number) => {
    const queued = jobsRef.current.filter(j => j.status === 'queued' && j.stepIndex === stepIndex)
    if (queued.length === 0) return
    const nextIdx = stepIndex + 1 >= pipeline.length ? 0 : stepIndex + 1
    const nextGroup = pipeline[nextIdx]
    const nextBaseName = nextGroup[0].baseName
    const nextPositions = machinePositions.get(nextBaseName)!
    const targetPos = nextPositions[0]

    const gridSize = Math.ceil(Math.sqrt(queued.length))

    for (let i = 0; i < queued.length; i++) {
      const row = Math.floor(i / gridSize)
      const col = i % gridSize
      const offsetX = (col - (gridSize - 1) / 2) * QUEUE_GRID_SPACING
      const offsetZ = QUEUE_Z_OFFSET + row * QUEUE_GRID_SPACING
      queued[i].boxGroup.position.set(targetPos.x + offsetX, SPHERE_HOVER_Y, targetPos.z + offsetZ)
      updateBadge(queued[i], i + 2)
    }
  }

  // Create a brand-new job and register its three.js objects with the
  // persistent container. Prefer recyclePooledJob() when a pooled job is
  // available to avoid geometry/material/texture churn.
  const createJob = (stepIndex: number, machineId: string, startStatus: 'processing' | 'queued'): JobState => {
    const sphereGroup = makeSphereGroup()
    const boxGroup = makeBoxGroup()
    const badge = makeBadge('2')
    boxGroup.add(badge)
    boxGroup.visible = false
    sphereGroup.visible = false
    const pos = getMachinePos(stepIndex, machineId)
    sphereGroup.position.copy(pos)
    boxGroup.position.copy(pos)
    containerRef.current.add(sphereGroup, boxGroup)
    return {
      id: jobIdCounter++,
      stepIndex,
      progress: 0,
      sphereGroup,
      boxGroup,
      badge,
      status: startStatus,
      machineId,
      lastQueueNum: null,
    }
  }

  // Reset an exited job's state/position/visibility and reuse it instead of
  // disposing + recreating three.js objects. Returns null if none available.
  const recyclePooledJob = (stepIndex: number, machineId: string, startStatus: 'processing' | 'queued'): JobState | null => {
    const pooled = jobsRef.current.find(j => j.status === 'pooled')
    if (!pooled) return null
    pooled.stepIndex = stepIndex
    pooled.machineId = machineId
    pooled.progress = 0
    pooled.status = startStatus
    pooled.lastQueueNum = null
    const pos = getMachinePos(stepIndex, machineId)
    pooled.sphereGroup.position.copy(pos)
    pooled.boxGroup.position.copy(pos)
    pooled.sphereGroup.visible = startStatus === 'processing'
    pooled.boxGroup.visible = startStatus === 'queued'
    return pooled
  }

  const spawnJob = (stepIndex: number, machineId: string, startStatus: 'processing' | 'queued'): JobState => {
    const recycled = recyclePooledJob(stepIndex, machineId, startStatus)
    if (recycled) return recycled
    const job = createJob(stepIndex, machineId, startStatus)
    jobsRef.current.push(job)
    return job
  }

  const exitJob = (job: JobState) => {
    // Pool rather than dispose: keeps geometry/material/texture allocation
    // bounded to MAX_ACTIVE_JOBS instead of growing unboundedly over a long
    // running session.
    job.status = 'pooled'
    job.sphereGroup.visible = false
    job.boxGroup.visible = false
  }

  // Shared by both the "processing just finished" and "queued, machine freed
  // up" cases: try to claim a free machine in the next step and start
  // traveling there; otherwise fall back to queued.
  const tryAdvanceToNextStep = (job: JobState, nextIdx: number): boolean => {
    const nextGroup = pipeline[nextIdx]
    for (const machine of nextGroup) {
      if (!machineBusy.get(machine.id)) {
        machineBusy.set(machine.id, true)
        job.machineId = machine.id
        job.progress = 0
        job.status = 'traveling'
        job.sphereGroup.visible = true
        job.boxGroup.visible = false
        job.sphereGroup.position.copy(getMachinePos(job.stepIndex, job.machineId))
        return true
      }
    }
    return false
  }

  useFrame((_, delta) => {
    if (!initialized.current && pipeline.length > 0) {
      const firstGroup = pipeline[0]
      for (const m of firstGroup) {
        spawnJob(0, m.id, 'processing')
        machineBusy.set(m.id, true)
      }
      for (let i = firstGroup.length; i < MAX_ACTIVE_JOBS; i++) {
        spawnJob(0, firstGroup[0].id, 'queued')
      }
      positionQueueStack(0)
      initialized.current = true
    }

    spawnTimer.current += delta
    if (spawnTimer.current >= SPAWN_INTERVAL_SEC) {
      spawnTimer.current = 0
      const activeCount = jobsRef.current.filter(j => j.status !== 'exited' && j.status !== 'pooled').length
      if (activeCount < MAX_ACTIVE_JOBS) {
        const firstGroup = pipeline[0]
        spawnJob(0, firstGroup[0].id, 'queued')
        positionQueueStack(0)
      }
    }

    for (const job of jobsRef.current) {
      if (job.status !== 'processing') continue
      const currentGroup = pipeline[job.stepIndex]
      if (!currentGroup) continue
      const currentBaseName = currentGroup[0].baseName
      const duration = machineDuration.get(currentBaseName) ?? 10
      job.progress += (1 / duration) * PROCESS_PROGRESS_MULT * delta

      if (job.progress < 1) continue

      machineBusy.set(job.machineId, false)
      const nextIdx = job.stepIndex + 1
      if (nextIdx >= pipeline.length) {
        exitJob(job)
        continue
      }
      const nextGroup = pipeline[nextIdx]

      if (nextGroup.length === 1) {
        const othersAtStep = jobsRef.current.filter(
          j => j !== job && j.stepIndex === job.stepIndex && (j.status === 'processing' || j.status === 'queued')
        )
        for (const other of othersAtStep) exitJob(other)
      }

      const assigned = tryAdvanceToNextStep(job, nextIdx)
      if (!assigned) {
        job.status = 'queued'
        job.sphereGroup.visible = false
        job.boxGroup.visible = true
      }
    }

    for (const job of jobsRef.current) {
      if (job.status !== 'queued') continue
      const nextIdx = job.stepIndex + 1
      if (nextIdx >= pipeline.length) {
        exitJob(job)
        continue
      }
      tryAdvanceToNextStep(job, nextIdx)
    }

    for (const job of jobsRef.current) {
      if (job.status !== 'traveling') continue

      const nextIdx = job.stepIndex + 1
      if (nextIdx >= pipeline.length) {
        exitJob(job)
        continue
      }
      const nextGroup = pipeline[nextIdx]

      job.progress += TRAVEL_SPEED * delta

      const fromPos = getMachinePos(job.stepIndex, job.machineId)
      const toPos = getMachinePos(nextIdx, job.machineId)
      const curve = connectionCurves.get(`${posKey(fromPos)}|${posKey(toPos)}`)

      const t = Math.min(job.progress, 0.999)
      if (curve) {
        const pos = curve.getPoint(t)
        job.sphereGroup.position.set(pos.x, pos.y, pos.z)
      } else {
        job.sphereGroup.position.lerpVectors(fromPos, toPos, t)
      }

      if (job.progress >= 1) {
        let assigned = false
        for (const machine of nextGroup) {
          if (!machineBusy.get(machine.id)) {
            machineBusy.set(machine.id, true)
            job.stepIndex = nextIdx
            job.machineId = machine.id
            job.progress = 0
            job.status = 'processing'
            job.sphereGroup.visible = false
            job.boxGroup.visible = false
            assigned = true
            break
          }
        }
        if (!assigned) {
          job.status = 'queued'
          job.sphereGroup.visible = false
          job.boxGroup.visible = true
          positionQueueStack(nextIdx)
        }
      }
    }

    const queuedSteps = new Set(jobsRef.current.filter(j => j.status === 'queued').map(j => j.stepIndex))
    for (const stepIdx of queuedSteps) positionQueueStack(stepIdx)
  })

  // Dispose all three.js resources on unmount.
  useEffect(() => {
    const container = containerRef.current
    return () => {
      for (const job of jobsRef.current) {
        disposeObject3D(job.sphereGroup)
        disposeObject3D(job.boxGroup)
      }
      jobsRef.current = []
      container.clear()
    }
  }, [])

  return <primitive object={containerRef.current} />
}